# bot configuration
BOT_TOKEN = '8565329646:AAHZh7jnk4LRcoPZN1_wQsrAeiG2LDvU8EQ'
KEYS_FILE = '/tg/keys.txt'
DB_FILE = '../purge_events.db'
JOIN_WINDOW_SECONDS = 60
JOIN_THRESHOLD = 5
ADMIN_SECRET = 'tW2H7mfymW48'
OWNER_CONTACT = 't.me/ownedgov'
LOG_DIR = '../logs'
# Optional: Telegram chat id where admin wants to receive notifications (int)
ADMIN_CHAT_ID = None
